# Yet Another Shell Emulator ( YASH )

It is an attempt to try making a shell in python. Has autocomplete as well as a fancy new theme. If there are any issues please add it in the issues section :smile:

First do pip3 install -r requirements.txt then do python3 main.py
[Here is the demo][https://replit.com/@NeoDrags/yash-demo]
